import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Solution {
    public List<Integer> twoOutOfThree(int[] nums1, int[] nums2, int[] nums3) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int n : nums1) {
            map.put(n, map.getOrDefault(n, 0) | 1);
        }
        for (int n : nums2) {
            map.put(n, map.getOrDefault(n, 0) | 2);
        }
        for (int n : nums3) {
            map.put(n, map.getOrDefault(n, 0) | 4);
        }
        List<Integer> ans = new ArrayList<>();
        for (int num : map.keySet()) {
            int mask = map.get(num);
            if (Integer.bitCount(mask) >= 2) {
                ans.add(num);
            }
        }
        return ans;
    }
}

